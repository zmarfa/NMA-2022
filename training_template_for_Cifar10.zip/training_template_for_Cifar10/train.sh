python train.py
zip Dataset.zip config.py data.npy label.npy wideresnet.pth.tar preactresnet18.pth.tar
